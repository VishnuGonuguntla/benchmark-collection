# AMD Zen HPL

Derived from:
>  High Performance Linpack Benchmark (HPL)
>  HPL - 2.3 - December 2, 2018

## Description:

HPL is a software package that solves a (random) dense linear
system  in   double  precision  (64   bits)   arithmetic   on 
distributed-memory  computers.   It can thus be regarded as a
portable as well as  freely  available implementation  of the
High Performance Linpack Benchmark.

This version has been optimized to run on AMD CPUs, including Zen5.

-----------------------------------------------------------------------------

## RELEASE 2024_10_08

### Dependencies:

* OpenMPI 4/5:  This release was built with OpenMPI 5.0.5, and should run
  without issue if OpenMPI 5 or 4 is in the environment.
* This release was built on Rocky Linux 8.6, and uses GLIBC 2.28.  It is
  expected to run on any EPYC system running Linux with GLIBC 2.28 or newer.

### Recommended system settings:

* BOOST: ON
* SMT: OFF
* NPS: 4
* Determinism: Power
* Transparent Hugepages: always


### How to run:

1. Ensure the above dependencies have been satisfied, and `mpirun` from OpenMPI is on your `$PATH`
2. Optionally, run the `./reset-system.sh` script to set various OS parameters to recommended values.
3. Optionally, create an HPL.dat file, as described in the documentation. 
   AMD Zen HPL will auto-tune to select reasonable default parameters, so an HPL.dat file is not required. By default, AMD_Zen_HPL will attempt to use roughly 90% of system memory.
4. For single-node runs, run `./run.sh`. For multi-node runs, adapt the`mpirun` line from `run.sh` to suit the local site.
   Recommended arguments to `mpirun` are:
    `--bind-to core --map-by socket:PE=$NUM_CORES_PER_SOCKET` - to specify 1 MPI rank per socket, with `$NUM_CORES_PER_SOCKET` (ideally set to number of cores per socket) CPUs assigned to the rank.


## Licensing
Please read Copyright Notice and Licensing terms in "AMD Zen HPL EULA (2024_10).pdf" file present in the same directory.

## Support
Please contact: toolchainsupport@amd.com for bugs and issues.

-----------------------------------------------------------------------------
