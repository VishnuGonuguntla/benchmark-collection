#!/bin/bash

# On the off chance OMPI_MCA is set to UCX-only, disable that
unset OMPI_MCA_osc

NT=$(lscpu | awk '/per socket:/{print $4}')
NR=$(lscpu | awk '/Socket/{print $2}')
MAP_BY=socket

mpidir=$(realpath $(dirname $(which mpirun))/..)

export LD_LIBRARY_PATH=${mpidir}/lib:${mpidir}/lib64:$LD_LIBRARY_PATH

$(which mpirun) --map-by ${MAP_BY}:PE=$NT --bind-to core -np $NR  \
    -x OMP_NUM_THREADS=$NT \
    ./xhpl "$@"
